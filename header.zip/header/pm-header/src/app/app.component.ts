import { Component } from '@angular/core';

@Component({
  selector: 'pm-header',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'pm-header';
}
